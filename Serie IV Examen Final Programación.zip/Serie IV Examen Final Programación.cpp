/* Maderlaine Vanessa Aldana Martinez Carne 0909-20-6881
Ingenieria en Sistemas Universidad Mariano Galvez 
Examen Final Serie IV Programaci�n*/
 
 
//Declaracion de libreras 
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cstdlib>
 
using namespace std;

//declaracion de variables
struct nodo{
     int nro;
     struct nodo *izq, *der;
};
typedef struct nodo *ABB;
   
ABB createNodo(int x)
{
     ABB nuevoNodo = new(struct nodo);
     nuevoNodo->nro = x;
     nuevoNodo->izq = NULL;
     nuevoNodo->der = NULL;
     return nuevoNodo;
}
 
void insert(ABB &arbol, int x)
{
     if(arbol==NULL)
     {
           arbol = createNodo(x);
     }
     else if(x < arbol->nro)
          insert(arbol->izq, x);
     else if(x > arbol->nro)
          insert(arbol->der, x);
}
 
void preOrden(ABB arbol)
{
     if(arbol!=NULL)
     {
          cout << arbol->nro <<" ";
          preOrden(arbol->izq);
          preOrden(arbol->der);
     }
}
 
void enOrden(ABB arbol)
{
     if(arbol!=NULL)
     {
          enOrden(arbol->izq);
          cout << arbol->nro << " ";
          enOrden(arbol->der);
     }
}
 
void postOrden(ABB arbol)
{
     if(arbol!=NULL)
     {
          postOrden(arbol->izq);
          postOrden(arbol->der);
          cout << arbol->nro << " ";
     }
}
 
void mostrarArbol(ABB arbol, int n)
{
     if(arbol==NULL)
          return;
     mostrarArbol(arbol->der, n+1);
     for(int i=0; i<n; i++)
         cout<<"   ";
     cout<< arbol->nro <<endl;
     mostrarArbol(arbol->izq, n+1);
}
 
bool buscar(ABB arbol, int dato)
{
     int r=0;   // dato no encontrado
     if(arbol==NULL)
        return r;
     if(dato<arbol->nro)
         r = buscar(arbol->izq, dato);
     else if(dato> arbol->nro)
         r = buscar(arbol->der, dato);
     else
       r = 1;   // dato encontrado
     return r;
}
 
int main()
{
    ABB arbol = NULL;   // Arbol creado
    int n;  // numero de nodos del arbol
    int x; // elemento a insertar en cada nodo
  int option;
  int num;
  int nodo;
  
  
  do{
  	cout<<"**********************************************************"<<endl;
  	cout<<"*                MENU DE OPCIONES                        *"<<endl;
  	cout<<"**********************************************************"<<endl;
    cout<<"1.- Insertar un nodo en el arbol                         *"<<endl;
    cout<<"2.- Mostrar el arbol completo                            *"<<endl;
    cout<<"3.- Buscar un nodo especifico                            *"<<endl;
    cout<<"4.- Recorrer el arbol, pre-orden, in-orden, pos-orden    *"<<endl;
    cout<<"5.- Borrar un nodo del arbol                             *"<<endl;
    cout<<"6.- Finalizar el programa                                *"<<endl;
    cout<<"**********************************************************"<<endl;
    cout<<"Opcion: ";
    cin>>option;
    
    switch(option){ system("cls");//Limpiar pantalla
    	
      case 1: 
	  		system("cls");//Limpiar pantalla
			cout << " Ingresa el numero de nodos del arbol:  ";
            cin >> n;
            cout << endl;
            for(int i=0; i<n; i++)
            {
                cout << " Numero del nodo " << i+1 << ": ";
                cin >> x;
                insert( arbol, x);
            }
            _getch();
            system("cls");//Limpiar pantalla
            break;
            
      case 2: 
	  		system("cls");//Limpiar pantalla
			cout << "\n Mostrando ABB \n\n";
            mostrarArbol( arbol, 0);
            _getch();
            system("cls");//Limpiar pantalla
            break;
           
            
      case 3: 
	  		system("cls");//Limpiar pantalla
			cout<<"Nodo que quieres buscar: "<<endl;
            cin>> nodo;
            
            if(buscar(arbol, num)){
            cout<<"Nodo encontrado"<<endl;
            getch();
          }else{
            cout<<"Nodo no encontrado"<<endl;
            getch();
          }
          	_getch();
          	system("cls");//Limpiar pantalla
         	break;
          
      case 4: 
	  		system("cls");//Limpiar pantalla
			cout << "\n Recorridos del ABB";
          	cout << "\n\n Pre Orden  :  ";   preOrden(arbol);
            cout << "\n\n In orden   :  ";   enOrden(arbol);
            cout << "\n\n Pos Orden :  ";   postOrden(arbol);
            cout <<endl;
            _getch();
            system("cls");//Limpiar pantalla
            break;
            
      case 5:
      		system("cls");//Limpiar pantalla
	  		cout<<endl;
	  		cout<<"\n Introduzca el nodo a eliminar"<<endl<<endl;
          	//funci�n para eliminar los nodos
          	system("cls");//Limpiar pantalla
			break;
          	
      case 6: 
	  		system("cls");//Limpiar pantalla
			cout<<"Finalizar el programa";
          	break;
    }
  }while(option!=6);
    cout << endl << endl;
    system("pause");
    return 0;
 }
 /* Maderlaine Vanessa Aldana Martinez Carne 0909-20-6881
Ingenieria en Sistemas Universidad Mariano Galvez 
Examen Final Serie IV Programaci�n*/

